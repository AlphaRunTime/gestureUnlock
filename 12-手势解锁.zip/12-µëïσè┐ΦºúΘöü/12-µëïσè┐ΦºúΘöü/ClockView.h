//
//  ClockView.h
//  12-手势解锁
//
//  Created by 刘国强 on 17/4/10.
//  Copyright © 2017年 TZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClockView : UIView

@end
