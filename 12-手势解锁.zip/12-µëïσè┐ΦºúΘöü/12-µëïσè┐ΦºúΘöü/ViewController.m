//
//  ViewController.m
//  12-手势解锁
//
//  Created by 刘国强 on 17/4/10.
//  Copyright © 2017年 TZ. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
//    self.edgesForExtendedLayout = UIRectEdgeNone;
}

- (BOOL)prefersStatusBarHidden{
    return YES;
}
- (IBAction)removeGSPwd:(UIButton *)sender {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"keyPwd"];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
