//
//  ClockView.m
//  12-手势解锁
//
//  Created by 刘国强 on 17/4/10.
//  Copyright © 2017年 TZ. All rights reserved.
//

#import "ClockView.h"

#define keyPassword @"keyPwd"

@interface ClockView ()


/**
 存放的都是当前选中的按钮
 */
@property (nonatomic , strong) NSMutableArray *selectedBtnArray;

/* 当前手指所在的点 */
@property(nonatomic , assign)CGPoint curPoint;

@end

@implementation ClockView

- (NSMutableArray *)selectedBtnArray{
    if (!_selectedBtnArray) {
        _selectedBtnArray = [NSMutableArray array];
    }
    return _selectedBtnArray;
}

- (void)awakeFromNib{
    [super awakeFromNib];
    
    // 初始化
    [self setUp];
}

// 搭建界面,添加按钮
- (void)setUp{
    for (int i = 0; i<9; i++) {
        // 创建按钮,设置按钮图片
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.userInteractionEnabled = NO;
        btn.tag = i;
        // 设置按钮图片
        [btn setImage:[UIImage imageNamed:@"gesture_node_normal"] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:@"gesture_node_selected"] forState:UIControlStateSelected];
        
        [self addSubview:btn];
    }
}

- (void)layoutSubviews{
    [super layoutSubviews];
    
    // 取出每一个按钮, 设置按钮的frame
    
    CGFloat x = 0;
    CGFloat y = 0;
    CGFloat btnWh = 74;
    // 总共多少列
    int columns = 3;
    // 每一列间距
    CGFloat margin = (self.bounds.size.width - (columns * btnWh)) / (columns + 1);
    
    for (int i = 0; i<self.subviews.count; i++) {
        
        x = margin + i % columns * (btnWh + margin);
        y = margin + i / columns * (btnWh + margin);
        
        // 取出每一个按钮
        UIButton *btn = self.subviews[i];
        btn.frame = CGRectMake(x, y, btnWh, btnWh);
    }
    
}

// 获取当前点
- (CGPoint)getCurrentPoint:(NSSet<UITouch *> *)touches{
    
    // 1.获取当前手指所在的点
    UITouch *touch = [touches anyObject];
    CGPoint curP = [touch locationInView:self];
    return curP;
}

// 给定一个点,判断给定的点在不在按钮上
// 如果在按钮上,返回当前所在的按钮;如果不在,返回nil;
- (UIButton *)btnRectContainsPoint:(CGPoint)point{
    
    for (UIButton *btn in self.subviews) {
        
        if (CGRectContainsPoint(btn.frame, point)) {
            // 让当前按钮成为选中状态
            // btn.selected = YES;
            return btn;
        }
    }
    return nil;
}

#pragma mark - 手指开始点击
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    // 当前手指所在的点在不在按钮上,如果在让按钮成为选中状态
    // 1.获取当前手指所在的点
    // UITouch *touch = [touches anyObject];
    // CGPoint curP = [touch locationInView:self];
    CGPoint curP = [self getCurrentPoint:touches];
    // 2.判断点在不在按钮上
    // 取出所有的按钮进行判断
    UIButton *btn = [self btnRectContainsPoint:curP];
    if (btn) {
        // 让当前按钮成为选中状态
        btn.selected = YES;
        // 保存当前选中的按钮
        [self.selectedBtnArray addObject:btn];
    }
}

#pragma mark - 手指移动
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    // 当前手指所在的点在不在按钮上,如果在让按钮成为选中状态
    // 1.获取当前手指所在的点
    // UITouch *touch = [touches anyObject];
    // CGPoint curP = [touch locationInView:self];
    CGPoint curP = [self getCurrentPoint:touches];
    // 记录当前手指所在的点
    self.curPoint = curP;
    // 2.判断点在不在按钮上
    // 取出所有的按钮进行判断
    UIButton *btn = [self btnRectContainsPoint:curP];
    if (btn && btn.selected == NO) {
        // 让当前按钮成为选中状态
        btn.selected = YES;
        [self.selectedBtnArray addObject:btn];
    }
    // 重绘
    [self setNeedsDisplay];
}

#pragma mark - 手指离开
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    NSMutableString *pwdStr = [NSMutableString string];
    // 1. 取消所有选中的按钮
    for (UIButton *btn in self.selectedBtnArray) {
        // NSLog(@"%ld",btn.tag);
        [pwdStr appendFormat:@"%ld",btn.tag];
        btn.selected = NO;
    }
    
    // 2. 清空路径
    [self.selectedBtnArray removeAllObjects];
    [self setNeedsDisplay];
    
    
    // 3. 查看当前选中按钮的顺序
    NSString *keyPwd = [[NSUserDefaults standardUserDefaults] objectForKey:keyPassword];
    if (!keyPwd) {
        [[NSUserDefaults standardUserDefaults] setObject:pwdStr forKey:keyPassword];
        [[NSUserDefaults standardUserDefaults] synchronize];
        UIAlertView *alertV = [[UIAlertView alloc] initWithTitle:@"请再次输入密码" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertV show];
        NSLog(@"第一次密码 : %@",pwdStr);
    }else{
        if ([keyPwd isEqualToString:pwdStr]) {
            NSLog(@"密码正确");
            UIAlertView *alertV = [[UIAlertView alloc] initWithTitle:@"手势输入正确" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alertV show];
        }else{
            NSLog(@"密码错误");
            UIAlertView *alertV = [[UIAlertView alloc] initWithTitle:@"手势输入错误" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alertV show];
        }
    }
    
}


- (void)drawRect:(CGRect)rect{
    if (self.selectedBtnArray.count) {
        // 1.创建路径
        UIBezierPath *path = [UIBezierPath bezierPath];
        // 2.取出所有保存的选中的按钮
        for (int i = 0; i<self.selectedBtnArray.count; i++) {
            // 取出每一个按钮
            UIButton *btn = self.selectedBtnArray[i];
            // 判断当前按钮是不是第一个按钮
            if (i == 0) {
                // 如果是, 设置成路径的起点
                [path moveToPoint:btn.center];
            }else{
                [path addLineToPoint:btn.center];
            }
        }
        
        // 添加一根线到当前手指所在的点
        [path addLineToPoint:self.curPoint];
        
        // 设置路径状态
        [path setLineWidth:10];
        [[UIColor redColor] set];
        [path setLineJoinStyle:kCGLineJoinRound];
        
        // 3. 开始绘制路径
        [path stroke];
        
    }
    
}



































@end
